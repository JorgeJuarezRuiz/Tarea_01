import java.util.Scanner;

public class Tarea1 {
    public static void main(String[] args) {
        System.out.println("Tarea 1\nNombre:Jorge Daniel Juárez Ruiz\nMatricula:A01376425");
        Scanner teclado=new Scanner(System.in);
        System.out.println("Teclea tu día de nacimiento:");
        int dia= teclado.nextInt();
        System.out.println("Teclea tu mes de nacimiento:");
        int mes= teclado.nextInt();
        System.out.println("Teclea tu año de nacimiento:");
        int año= teclado.nextInt();
        Fecha fecha=new Fecha(dia,mes,año);
        System.out.println("Teclea tu nombre:");
        teclado.nextLine();
        String nombre= teclado.nextLine();
        FrecuenciaCardiaca frecCard= new FrecuenciaCardiaca(nombre,fecha);
        System.out.println("Nombre:"+nombre);
        System.out.println("Fecha de Nacimiento:"+fecha);
        System.out.println("Edad:"+fecha.calcularEdad());
        System.out.println("Frecuencia cardiaca máxima:"+frecCard.getMaximaFrecuenciaCardiaca());
        System.out.println("Frecuencia recomendada: ["+(frecCard.getMaximaFrecuenciaCardiaca()*0.5)+","+(frecCard.getMaximaFrecuenciaCardiaca()*0.85)+"]");
        
        
        
    }
 
}
